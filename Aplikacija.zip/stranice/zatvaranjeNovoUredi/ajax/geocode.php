

<?php

include "../../../config.inc.php";

function getCoordinates($address) {

    $address="Zagreb, ".$address;
    
    $url = "https://nominatim.openstreetmap.org/search?q=" . urlencode($address) . "&format=json";

    // Postavke proxy servera
    $proxy = PROXYURL; // Primer: http://123.45.67.89:8080

    // cURL inicijalizacija
    $ch = curl_init($url);

    // Postavljanje cURL opcija
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Vraća rezultat umesto da ga ispiše
    if ($proxy){
        curl_setopt($ch, CURLOPT_PROXY, $proxy); // Postavlja proxy
        curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP); // Tip proxyja: HTTP, HTTPS, SOCKS4, SOCKS5
    }
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    
    if (CURLREFERER != "")
        curl_setopt($ch, CURLOPT_REFERER, CURLREFERER);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        curl_close($ch);
        return false;
    } else {
        curl_close($ch);

        $polje=json_decode($response, true);

        foreach ($polje as $p){
            if (str_contains($p["display_name"], "Grad Zagreb")){
                return array("lat"=>$p["lat"], "lon"=>$p["lon"]);
                die();
            }
        }

        $coord=json_decode($response, true)[0];
        return array("lat"=>$coord["lat"], "lon"=>$coord["lon"]);
        die();
        
    }
}

$coordinates = getCoordinates($_POST["adresa"]);
echo json_encode($coordinates);
die();


?>